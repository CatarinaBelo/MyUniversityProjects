package environment;

import java.util.LinkedList;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import game.*;

/**
 * Main class for game representation.
 *
 * @author luismota
 */
public class Cell {
    private BoardPosition position;
    private Snake ocuppyingSnake = null;
    private GameElement gameElement = null;
    private Lock lock = new ReentrantLock();
    private Condition cellToGO = lock.newCondition();


    public GameElement getGameElement() {
        return gameElement;
    }

    /*public static void from(DTO dto, Board board) {
        var cell = board.getCell(dto.getPosition());
        if (dto.isObstacle()) {
            cell.setGameElement(new Obstacle(board));
        }
        if (dto.isGoal()) {
            cell.setGameElement(new Goal(board));
        }
    }*/

    //Vai buscar a cell do board que tem a mesma posição do objeto DTO
    // e cria um novo objeto(goal ou obstaculo) consoante o objeto DTO que lá está
    public static Cell mapFrom(ActualizationDTO dto, Board board) {
        var cell = new Cell(dto.getPosition());
        if (dto.isObstacle()) {
            var obstacles = new Obstacle(board);
            obstacles.setRemainingMoves(dto.getValor());
            cell.gameElement = obstacles;

        } else {
            var goal = new Goal(board);
            goal.setValue(dto.getValor());
            cell.gameElement = goal;
        }
        return cell;
    }

    /*
        public static void from(List<DTO> snakeCells, int snakeId, Board board) {
            if (!snakeCells.isEmpty()) {
                if (snakeCells.get(0).isHumanSnake()) {

                    var snake = new HumanSnake(snakeId, board);
                    // var t = new LinkedList<Cell>();
                    snakeCells.forEach(dto -> {
                        var cell = board.getCell(dto.getPosition());
                        cell.ocuppyingSnake = snake;
                        //  t.add(cell);

                    });
                    // snake.setCells(t);
                    // board.addSnake(snake);
                }
                if (snakeCells.get(0).isAutomatic()) {
                    var snake = new AutomaticSnake(snakeId, board);
                    //var t = new LinkedList<Cell>();

                    snakeCells.forEach(dto -> {
                        var cell = board.getCell(dto.getPosition());
                        cell.ocuppyingSnake = snake;
                        //  t.add(cell);

                    });
                    //snake.setCells(t);
                    // board.addSnake(snake);

                }
            }
        }
    */

    // O DTO traz uma LinkedList de boardPositions da cobra
    public static LinkedList<Cell> parseSnakeDTO(ActualizationDTO snakeDTO, int snakeId, Board board) {
        var cells = new LinkedList<Cell>();
        if (snakeDTO.isHumanSnake()) {

            var snake = new HumanSnake(snakeId, board);

            snakeDTO.getPositions().forEach(position -> {
                // vou ao board buscar a cell correspondente a essa posição e meto lá a Snake
                var cell = new Cell(position);
                cell.ocuppyingSnake = snake;
                cells.add(cell);
            });
            // adiciona as cells do corpo à snake
            snake.setCells(cells);
            // adiciona a snake ao board
            board.addSnake(snake);
        }
        if (snakeDTO.isAutomatic()) {
            var snake = new AutomaticSnake(snakeId, board);
            snakeDTO.getPositions().forEach(position -> {
                var cell = board.getCell(position);
                cell.ocuppyingSnake = snake;
                cells.add(cell);
            });
            snake.setCells(cells);
            board.addSnake(snake);

        }
        return cells;
    }

    public Cell(BoardPosition position) {
        super();
        this.position = position;
    }

    public BoardPosition getPosition() {
        return position;
    }

    // Usando lock implícito - synchronized
	/*public synchronized void request(Snake snake) throws InterruptedException {

		while (isOcupied()) {
			System.out.println(this.gameElement);
			System.out.println(this.getOcuppyingSnake());
			wait();
		}

		snake.move(this);
		ocuppyingSnake = snake;
	}

	public synchronized void release() throws InterruptedException {
		ocuppyingSnake = null;
		gameElement=null;

		notifyAll();
	}*/

    // Usando lock explícito - Lock e variáveis condicionais
    public void request(Snake snake) throws InterruptedException {
        lock.lock();

        if (snake instanceof HumanSnake && isOcupied()) {
            lock.unlock();
            return;
        }
        while (isOcupied()) {
            cellToGO.await();
        }

        snake.move(this);
        ocuppyingSnake = snake;

        lock.unlock();
    }

    public void release() throws InterruptedException {
        lock.lock();

        ocuppyingSnake = null;
        gameElement = null;

        cellToGO.signalAll();

        lock.unlock();
    }

    public boolean isOcupiedBySnake() {
        return ocuppyingSnake != null;
    }


    public synchronized void setGameElement(GameElement element) {
        // TODO coordination and mutual exclusion
        gameElement = element;

    }

    public boolean isOcupied() {
        return isOcupiedBySnake() || (gameElement != null && gameElement instanceof Obstacle);
    }


    public Snake getOcuppyingSnake() {
        return ocuppyingSnake;
    }


    public synchronized Goal removeGoal() {
        Goal newgoal = null;
        if (this.gameElement instanceof Goal) {
            newgoal = new Goal(((Goal) this.gameElement).getBoard());
            this.gameElement = null;
        }
        return newgoal;
    }

    public void removeObstacle() {
        if (this.gameElement instanceof Obstacle) {
            this.gameElement = null;
        }
    }


    public Goal getGoal() {
        return (Goal) gameElement;
    }


    public boolean isOcupiedByGoal() {
        return (gameElement != null && gameElement instanceof Goal);
    }


}
