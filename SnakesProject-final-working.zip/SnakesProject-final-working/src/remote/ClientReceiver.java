package remote;

import game.ActualizationDTO;

import java.io.ObjectInputStream;
import java.net.Socket;
import java.util.LinkedList;

public class ClientReceiver extends Thread {
    private Socket socket;
    private RemoteBoard board;

    public ClientReceiver(Socket socket, RemoteBoard board) {
        this.socket = socket;
        this.board = board;
    }

    @Override
    public void run() {

    /*
        fica espera lista dto
                pinta

     */
        try (ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream())) {
            System.out.println("Este é o socket clientReceiver " + socket);
            while (true) {
                // Espera por uma lista de DTOs do servidor
                Object receivedObject = inputStream.readObject();
                if (receivedObject instanceof LinkedList<?>) {
                    LinkedList<ActualizationDTO> receivedList = (LinkedList<ActualizationDTO>) receivedObject;
                    board.processAttDTO(receivedList);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            // Lidar com exceções, como desconexão do servidor, aqui
        }
    }
}
