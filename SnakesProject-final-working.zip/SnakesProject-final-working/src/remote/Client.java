package remote;


import gui.BoardComponent;
import gui.SnakeGui;

import javax.swing.*;
import java.io.*;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Observable;
import java.util.Observer;

/**
 * Remore client, only for part II
 *
 * @author luismota
 */

public class Client implements Observer {

    private BufferedReader in;
    private PrintWriter out;
    private Socket socket;
    private RemoteBoard remoteBoard;

    private ClientReceiver receiver;

    private BoardComponent boardComponent;

    public static final int SERVER_PORT = 8080;
    private final JFrame frame = new JFrame("Cliente");

    public static void main(String[] args) throws ClassNotFoundException, InterruptedException {
        new Client().runClient();
    }

    public void runClient() throws ClassNotFoundException, InterruptedException {
        try {

            RemoteBoard remoteBoard = new RemoteBoard(this);
            this.remoteBoard = remoteBoard;

            SnakeGui snakeGui = new SnakeGui(remoteBoard, 600, 0);

            boardComponent = snakeGui.getBoardComponent();
            boardComponent.setRemoteBoard(remoteBoard);
            snakeGui.init();

            connectToServer();
            //startTheGame();

        } catch (IOException e) {// ERRO...
        }
    }

    void startTheGame() throws IOException, ClassNotFoundException, InterruptedException {
        while (true) {
            // Le a lista de jogadores vindos do servidor
            //getPlayers();

            // Verificar se o jogo acabou, fazer código mais tarde


        }
    }

    public void sendDirection(String direction) {
        //System.out.println("Key " + direction);
        sendMessages(direction);
    }


    void connectToServer() throws IOException {
        InetAddress endereco = InetAddress.getByName(null);
        System.out.println("Endereco:" + endereco);

        socket = new Socket(endereco, SERVER_PORT);
        System.out.println("Socket:" + socket);

        receiver = new ClientReceiver(socket, remoteBoard); // Passa 'this' se ClientReceiver precisa chamar métodos de Client(?????)
        receiver.start();
    }

    void sendMessages(String direction) {
        // envia as direções do movimento da cobra sempre que as teclas das direções forem primidas
        PrintWriter ooStream = null;
        try {
            ooStream = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())), true);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        // Envia como texto para o servidor neste caso é a direção
        ooStream.println(direction);
    }


    @Override
    public void update(Observable o, Object arg) {
    }
}
