package remote;

import java.awt.*;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

import environment.Board;
import environment.BoardPosition;
import environment.Cell;
import game.ActualizationDTO;

import javax.swing.*;

/**
 * Remote representation of the game, no local threads involved.
 * Game state will be changed when updated info is received from Srver.
 * Only for part II of the project.
 *
 * @author luismota
 */
public class RemoteBoard extends Board {
    //private String lastPressedDirection = null;
    private Client client;
    private final Image obstacleImage = new ImageIcon("obstacle.png").getImage();

    public RemoteBoard(Client client) {
        super();
        this.client = client;
    }

    public void sendDirection(String key) {
        if (!isFinished) {
            client.sendDirection(key);
        }
    }

    public synchronized void removeOldSnakes() {
        snakes = new LinkedList<>();
    }


    public void finishGame(boolean b) {
        isFinished = b;
    }

    @Override
    public void handleKeyPress(int keyCode) {
       /* System.out.println("Key pressed: " + keyCode);
        switch (keyCode) {
            case 0x25 -> lastPressedDirection = "P1|" + Direction.LEFT;
            case 0x26 -> lastPressedDirection = "P1|" + Direction.UP;
            case 0x27 -> lastPressedDirection = "P1|" + Direction.RIGHT;
            case 0x28 -> lastPressedDirection = "P1|" + Direction.DOWN;
        }*/
    }

    @Override
    public void handleKeyRelease() {
        //lastPressedDirection = null;
    }

    @Override
    public void init() {

        // inicializar HumanSnakes?
    }

    public synchronized void resetCellsAndAdd(List<Cell> newCells) {
        this.resetCells();
        newCells.forEach(cell -> super.cells[cell.getPosition().x][cell.getPosition().y] = cell);
    }

    protected void resetCells() {
        for (int x = 0; x < NUM_COLUMNS; x++) {
            for (int y = 0; y < NUM_ROWS; y++) {
                cells[x][y] = new Cell(new BoardPosition(x, y));
            }
        }
    }
    /*public String getLastPressedDirection() {
        //handleKeyPress();
        return lastPressedDirection;
    }*/

    public synchronized void processAttDTO(LinkedList<ActualizationDTO> receivedList) {
        //Implementar a lógica para processar a lista de DTOs recebida

        //Filtra a lista que recebemos pelas Snakes
        var snakesDtos = receivedList.stream()
                .filter(c -> c.isAutomatic() || c.isHumanSnake())
                .toList();

        //Filtra a lista que recebemos pelos restantes objetos(obstaculo e goal)
        var remainingObjects = receivedList.stream()
                .filter(c -> !(c.isAutomatic() || c.isHumanSnake()))
                .toList();

        var findGoal = receivedList.stream().anyMatch(c -> c.isGoal());

        if(!findGoal){
            finishGame(true);
        }

        // remove as snakes antigas do Board
        removeOldSnakes();

        // Retorna a lista de Cells das Snakes, uma lista de cells de ambas as Snake
        var snakeCells = snakesDtos.stream()
                .map(entry -> Cell.parseSnakeDTO(entry, entry.getSnakeId(), this))
                .flatMap(List::stream)
                .collect(Collectors.toList());

        // Retorna uma lista com as cells dos restantes objetos
        var remainingCells =remainingObjects.stream()
                .map( dto -> Cell.mapFrom(dto, this))
                .toList();

        snakeCells.addAll(remainingCells);
        resetCellsAndAdd(snakeCells);
        setChanged();
    }
}
