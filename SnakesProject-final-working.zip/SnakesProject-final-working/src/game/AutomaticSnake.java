package game;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.swing.text.Position;

import environment.LocalBoard;
import game.enumeration.Direction;
import gui.SnakeGui;
import environment.Cell;
import environment.Board;
import environment.BoardPosition;


public class AutomaticSnake extends Snake {




    //private volatile boolean exit = false;
    public AutomaticSnake(int id, Board board) {
        super(id, board);

    }


    //Adiciona à lista cellToAdd a nova head da snake
    public Cell moveAutomatic(BoardPosition goalPosition, BoardPosition headPosition) {
        try {

            Direction direction = getMovingDirection(goalPosition, headPosition);
            BoardPosition newPosi = fromDirection(direction, headPosition);
            try{

            Cell newHead = super.getBoard().getCell(newPosi);
            newHead.request(this);


            return newHead;
            }catch (ArrayIndexOutOfBoundsException e){
                System.out.println("");
            }
        return null;
        } catch (InterruptedException e) {
            //mais tarde implementar while para verificação se a randomPosition está disponível
            // e continuar à procura de uma nova posição random

            BoardPosition newRandomPosition = super.getBoard().getRandomPosition();

            //chamada recursiva ao método moveAutomatic
            return moveAutomatic(newRandomPosition, headPosition);
        }
    }

    @Override
    public void run() {
        doInitialPositioning();
        super.getBoard().setChanged();

        while (!super.getBoard().isFinished()) {
            try {
                Thread.sleep(Board.PLAYER_PLAY_INTERVAL);

                BoardPosition goalPosition = super.getBoard().getGoalPosition();
                Cell headCell = cells.peek();
                BoardPosition headPosition = headCell.getPosition();

                moveAutomatic(goalPosition,headPosition);


            } catch (InterruptedException e) {
                break;
            }
        }
    }

    public Direction getMovingDirection(BoardPosition goal, BoardPosition head) {
        int xDistance = goal.x - head.x;
        int yDistance = goal.y - head.y;

        Direction direction;
        if (Math.abs(xDistance) >= Math.abs(yDistance)) {
            //se a distancia for positiva vamos para a direita, caso seja negativa vamos para a esquerda
            direction = xDistance >= 0 ? Direction.RIGHT : Direction.LEFT;

            //posição desejada
            BoardPosition desiredPosition = new BoardPosition(head.x + direction.x, head.y);

            //verifica se o corpo da cobra está na posição que deseja ir
            BoardPosition finalDesiredPosition = desiredPosition;
            boolean desiredOccupied = super.cells.stream().anyMatch(c -> c.getPosition().equals(finalDesiredPosition));

            while (desiredOccupied || !getBoard().isWithinBoard(desiredPosition)) {
                //se der 0 vai UP se der 1 vai DOWN, ver enum Direction
                int random = Math.toIntExact(Math.round(Math.random()));
                direction = Direction.getYByValue(random);

                BoardPosition newDesiredPosition = new BoardPosition(head.x, head.y + direction.y);
                desiredPosition = newDesiredPosition;
                // verifica novamente se a nova posição para onde quer ir é nela mesma,
                // se for, continua a true e volta a entrar no while
                desiredOccupied = super.cells.stream().anyMatch(c -> c.getPosition().equals(newDesiredPosition));
            }
        } else {
            direction = yDistance >= 0 ? Direction.DOWN : Direction.UP;
            BoardPosition desiredPosition = new BoardPosition(head.x, head.y + direction.y);

            BoardPosition finalDesiredPosition = desiredPosition;
            boolean desiredOccupied = super.cells.stream().anyMatch(c -> c.getPosition().equals(finalDesiredPosition));

            while (desiredOccupied || !getBoard().isWithinBoard(desiredPosition)) {
                //se der 0 vai LEFT se der 1 vai RIGHT, ver enum Direction
                int random = Math.toIntExact(Math.round(Math.random()));
                direction = Direction.getXByValue(random);

                BoardPosition newDesiredPosition = new BoardPosition(head.x + direction.x, head.y);
                desiredPosition = newDesiredPosition;

                desiredOccupied = super.cells.stream().anyMatch(c -> c.getPosition().equals(newDesiredPosition));
            }
        }
        return direction;
    }

    public BoardPosition fromDirection(Direction direction, BoardPosition from) {
        switch (direction) {
            case LEFT, RIGHT -> {
                return new BoardPosition(from.x + direction.x, from.y);
            }
            case UP, DOWN -> {
                return new BoardPosition(from.x, from.y + direction.y);
            }
        }
        return null;
    }



}
