package game;

import environment.Board;
import environment.BoardPosition;
import environment.Cell;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.LinkedList;

public class Server {

    public static final int PORTO = 8080;
    private Board board;

    public Server(Board board){
    	this.board = board;
    }

    /*

    public static void main(String[] args) {
        try {
            new Server(board).startServing();
        } catch (IOException e) {
            // ...
        }
    }
    */

    public void startServing() throws IOException {
        // vou receber conexões de todos os que se conectarem neste porto ->
        // é bloqueante, fica aqui preso até receber conexão
        ServerSocket ss = new ServerSocket(PORTO);
        try {
            while (true) {
                Socket socket = ss.accept();

                DealWithClient Dwc = new DealWithClient(socket, board);
                Dwc.start();

            }
        } finally {
            ss.close();
        }

    }

    //sempre que existe uma atualizacao

    /*
    funcao para criar a lista dto
            localboard iterate cells criar dto

     */

    public synchronized static LinkedList<ActualizationDTO> createDtoList(Board board) {
        LinkedList<ActualizationDTO> dtoList = new LinkedList<>();

        for (int x = 0; x < Board.NUM_COLUMNS; x++) {
            for (int y = 0; y < Board.NUM_ROWS; y++) {
                BoardPosition position = new BoardPosition(x, y);
                Cell cell = board.getCell(position);
                ActualizationDTO dto = new ActualizationDTO(position);

                if (cell.getGameElement() instanceof Obstacle) {
                    dto.setObstacle(true);
                    dto.setValor(((Obstacle) cell.getGameElement()).getRemainingMoves());
                    dtoList.add(dto);

                } else if (cell.getGameElement() instanceof Goal) {
                    dto.setGoal(true);
                    dto.setValor(((Goal) cell.getGameElement()).getValue());
                    dtoList.add(dto);

                }
            }
        }

        board.getSnakes().forEach( snake -> {
            ActualizationDTO dto = new ActualizationDTO(snake.getPath());
            dto.setSnakeId(snake.getIdentification());
            dto.setHumanSnake(snake instanceof HumanSnake);
            dto.setAutomatic(snake instanceof AutomaticSnake);
            dtoList.add(dto);
        });
        return dtoList;
    }
    //enciar todos clientes
}
