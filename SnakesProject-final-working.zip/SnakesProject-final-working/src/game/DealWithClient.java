package game;

import environment.Board;
import environment.BoardPosition;
import environment.Cell;
import game.enumeration.Direction;

import java.io.*;
import java.net.Socket;
import java.util.*;

import static game.Server.createDtoList;

public class DealWithClient extends Thread implements Observer {

    private Socket socket;
    private Board board;
    private Snake humanSnake1;
    private Random randomGenerator = new Random();


    public DealWithClient(Socket socket, Board board) {
        this.socket = socket;
        this.board = board;
        this.board.addObserver(this);
    }

    public void run() {
        try {
            synchronized (this) {
                humanSnake1 = new HumanSnake(randomGenerator.nextInt(100) + 1, board);
                humanSnake1.start();
                board.addSnake(humanSnake1);
                board.setChanged();
            }
            serve();

        } catch (IOException | InterruptedException e) {
            // matar jogadores quando a janela fecha?
            throw new RuntimeException(e);
        }

    }

    @Override
    public void update(Observable o, Object arg) {
        //System.out.println("Sending list");

    }


    void serve() throws IOException, InterruptedException {
        //criar thread sender
        var sender = new BoardInformationSender(socket, board);
        sender.start();

        while (true) {
            getDirection();
            // sleep(300);
        }

    }


    void getDirection() throws IOException, InterruptedException {
        // Verifica se na socket existe algo para ler

        InputStream inStreamStream = socket.getInputStream();
        BufferedReader outputStream = new BufferedReader(new InputStreamReader(inStreamStream));


        // le o que está na socket
        String value = outputStream.readLine();

        if (value != null) {
            String[] arrOfStr = value.split(";");
            if (Objects.equals(arrOfStr[0], "P1")) {
                Direction newDirection = Direction.valueOf(arrOfStr[1]);

                Cell headCell = humanSnake1.getCells().peek();
                BoardPosition headPosition = headCell.getPosition();

                BoardPosition newPosi = fromDirection(newDirection, headPosition);
                if(board.isWithinBoard(newPosi)) {
                    Cell newHead = board.getCell(newPosi);

                    // no request já é chamado o move da snake
                    // caso esteja ocupada ignora o movimento

                    newHead.request(humanSnake1);

                } else{
                    System.out.println("fora");
                }
            }
        }
    }

    public BoardPosition fromDirection(Direction direction, BoardPosition from) {
        switch (direction) {
            case LEFT, RIGHT -> {
                return new BoardPosition(from.x + direction.x, from.y);
            }
            case UP, DOWN -> {
                return new BoardPosition(from.x, from.y + direction.y);
            }
        }
        return null;
    }

    // onde envia os dados necessários para o cliente
    // private void sendPlayers(){

    //}


    public class BoardInformationSender extends Thread implements Observer {

        private Socket socket;
        private Board board;
        private Snake humanSnake1;
        private Random randomGenerator = new Random();
        ObjectOutputStream outStream;


        public BoardInformationSender(Socket socket, Board board) {
            this.socket = socket;
            this.board = board;
            try {
                outStream = new ObjectOutputStream(socket.getOutputStream());
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

            // this.board.addObserver(this);
        }

        public void run() {
            try {

                serve();

            } catch (IOException | InterruptedException e) {
                // matar jogadores quando a janela fecha?
                throw new RuntimeException(e);
            }

        }

        @Override
        public void update(Observable o, Object arg) {
            //System.out.println("Sending list");

        }


        void serve() throws IOException, InterruptedException {
            //criar thread sender
            while (true) {
                sendDtoList();
                sleep(20);
            }

        }

        private void sendDtoList() throws IOException {
            LinkedList<ActualizationDTO> dtoList = createDtoList(board);
            //System.out.println("Sending list with " + dtoList.size() + " elements");
            outStream.writeObject(dtoList);
            outStream.flush();
        }

    }


}
