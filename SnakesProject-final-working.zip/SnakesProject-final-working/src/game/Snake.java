package game;

import java.io.Serializable;
import java.util.LinkedList;

import environment.LocalBoard;
import gui.SnakeGui;
import environment.Board;
import environment.BoardPosition;
import environment.Cell;
/** Base class for representing Snakes.
 * Will be extended by HumanSnake and AutomaticSnake.
 * Common methods will be defined here.
 * @author luismota
 *
 */
public abstract class Snake extends Thread implements Serializable{
	private static final int DELTA_SIZE = 10;
	protected LinkedList<Cell> cells = new LinkedList<Cell>();
	protected int size = 5;
	protected int toGrow = 0;
	private int id;
	private Board board;

	@Override
	public void run(){
		System.out.println("batataatatatata");
	}
	
	public Snake(int id,Board board) {
		this.id = id;
		this.board=board;
		this.toGrow = size;
	}

	public void setCells(LinkedList<Cell> cells){
		this.cells=cells;
	}

	public int getSize() {
		return size;
	}

	public int getIdentification() {
		return id;
	}

	public int getLength() {
		return cells.size();
	}
	
	public LinkedList<Cell> getCells() {
		return cells;
	}
	public synchronized void move(Cell cell) throws InterruptedException {

		if (cells.size() > 0 && toGrow <= 0) {
			//remover da posição da cell
			cells.getLast().release();

			//remover da lista a última cell
			cells.removeLast();
		} else {
			toGrow--;
		}

		cells.add(0, cell);
		capturedGoal(cell);

		getBoard().setChanged();
	}
	
	public synchronized LinkedList<BoardPosition> getPath() {
		LinkedList<BoardPosition> coordinates = new LinkedList<BoardPosition>();
		for (Cell cell : cells) {
			coordinates.add(cell.getPosition());
		}

		return coordinates;
	}	
	protected void doInitialPositioning() {
		// Random position on the first column. 
		// At startup, snake occupies a single cell
		int posX = 0;
		int posY = (int) (Math.random() * Board.NUM_ROWS);
		BoardPosition at = new BoardPosition(posX, posY);
		
		try {
			board.getCell(at).request(this);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		cells.add(board.getCell(at));
		System.err.println("Snake "+getIdentification()+" starting at:"+getCells().getLast());		
	}
	
	public Board getBoard() {
		return board;
	}


	private void capturedGoal(Cell newHead)  {
		int newGoalValue = 0;

			// Captura o Goal e processa a lógica associada
			Goal goal = newHead.getGoal();
			if (goal != null) {
				newGoalValue = goal.captureGoal();
				this.toGrow += newGoalValue;
				checkForGameEnd(newGoalValue);
			}

	}


	//Função que verifica se o jogo acabou e desencadear o fim do jogo
	public void checkForGameEnd(int totalPrizeValue) {
		//ir buscar a variavel do goal para colocar o 9 com base no valor maximo do goal
		if ((totalPrizeValue + 1) >= Goal.MAX_VALUE) {
			System.out.println("Game Over! Snake " + getIdentification() + " won!");
			((LocalBoard)getBoard()).finishGame(true);

		}
	}

}
