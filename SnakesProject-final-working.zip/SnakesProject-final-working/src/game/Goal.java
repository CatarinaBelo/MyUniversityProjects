package game;

import environment.Board;
import environment.BoardPosition;
import environment.Cell;
import environment.LocalBoard;

public class Goal extends GameElement  {
	private int value=1;
	private Board board;

	//Valor original
	public static final int MAX_VALUE=10;

	//Valor para testes
	//public static final int MAX_VALUE=2;

	public Goal( Board board2) {
		super();
		this.board = board2;
	}
	
	public int getValue() {
		return value;
	}

	public Board getBoard(){
		return board;
	}

	public void incrementValue() throws InterruptedException {
		if (value < MAX_VALUE) {
			value++;
		}
	}
	public void setValue(int value){
		this.value = value;
	}

	public int captureGoal()  {
		try {
			incrementValue();
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
			return -1; // Ou outro valor de erro apropriado
		}

			BoardPosition oldPosition = board.getGoalPosition();
			Cell oldCell = board.getCell(oldPosition);

			oldCell.removeGoal();
			if (value < MAX_VALUE) {
				board.addGameElement(this);
			}


			//value começa a 1, incrementando vai para 2 e etc logo temos de fazer -1
		return (value-1);

	}



}
