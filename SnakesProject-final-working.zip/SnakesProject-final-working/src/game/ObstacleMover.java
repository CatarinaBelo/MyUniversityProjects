package game;

import environment.BoardPosition;
import environment.Cell;
import environment.LocalBoard;


public class ObstacleMover implements Runnable{
	private Obstacle obstacle;
	private LocalBoard board;

	public ObstacleMover(Obstacle obstacle, LocalBoard board) {
		super();
		this.obstacle = obstacle;
		this.board = board;
	}

	@Override
	public void run() {
		try {
			System.out.println("Obstacle " + obstacle.toString() + " is moving");
			while ( obstacle.getRemainingMoves() > 0) {
				Thread.sleep(obstacle.getMoveInterval());

				BoardPosition oldPosition = obstacle.getCurrentPosition();
				Cell oldCell = board.getCell(oldPosition);
				board.addGameElement(obstacle);
				oldCell.release();
				//oldCell.removeObstacle();

				board.setChanged();
				obstacle.decrementRemainingMoves();


			}
		} catch (InterruptedException e) {
			// A thread foi interrompida, geralmente um sinal para terminar
			//Thread.currentThread().interrupt();
		}


	}


}
