package game.enumeration;
public enum Direction {
    UP(0,-1),RIGHT(1,0),DOWN(0,1),LEFT(-1,0);
    public int x;
    public int y;
    Direction(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public static Direction getXByValue(int x){
        if (x == 0) {
            return LEFT;
        }
        return RIGHT;
    }
    public static Direction getYByValue(int y){
        if (y == 0) {
            return UP;
        }
        return DOWN;
    }
}