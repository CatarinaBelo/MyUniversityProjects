package game;


public abstract class GameElement{



}
