package game;

import environment.Board;
import environment.BoardPosition;
import environment.LocalBoard;

public class Obstacle extends GameElement {
	
	
	private static final int NUM_MOVES=3;
	private static final int OBSTACLE_MOVE_INTERVAL = 400;
	private int remainingMoves=NUM_MOVES;
	private Board board;

	private BoardPosition currentPosition;


	public Obstacle(Board board) {
		super();
		this.board = board;
	}


	public BoardPosition getCurrentPosition(){
		return currentPosition;
	}


	public void setCurrentPosition(BoardPosition newPosition){
		this.currentPosition=newPosition;
	}

	public int getRemainingMoves() {
		return remainingMoves;
	}


	public void decrementRemainingMoves() {
		if (remainingMoves > 0) {
			remainingMoves--;
		}
	}

	public void setRemainingMoves(int remainingMoves){
		this.remainingMoves = remainingMoves;
	}

	public long getMoveInterval() {
		return OBSTACLE_MOVE_INTERVAL;
	}
}

