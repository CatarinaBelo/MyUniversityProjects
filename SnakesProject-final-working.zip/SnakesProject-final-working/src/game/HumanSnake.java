package game;

import environment.Board;
import environment.BoardPosition;
import environment.Cell;
import game.enumeration.Direction;
import remote.RemoteBoard;

import java.rmi.Remote;

/** Class for a remote snake, controlled by a human
  * 
  * @author luismota
  *
  */
public class HumanSnake extends Snake {

	public HumanSnake(int id,Board board) {
		super(id,board);
	}

	@Override
	public void run() {
		doInitialPositioning();
		super.getBoard().setChanged();
	}
}

