package game;

import environment.BoardPosition;

import java.io.Serializable;
import java.util.LinkedList;


public class ActualizationDTO implements Serializable {
    private BoardPosition position;
    private LinkedList<BoardPosition> positions;
    private boolean humanSnake;
    private int snakeId;
    private boolean obstacle;
    private boolean goal;
    private boolean automatic;
    private int valor;

    public ActualizationDTO(BoardPosition position) {
        this.position = position;
    }
    public ActualizationDTO(LinkedList<BoardPosition> positions) {
        this.positions = positions;
    }


    public LinkedList<BoardPosition> getPositions() {
        return positions;
    }
    public BoardPosition getPosition() {
        return position;
    }

    public void setPosition(BoardPosition position) {
        this.position = position;
    }

    public boolean isHumanSnake() {
        return humanSnake;
    }

    public void setHumanSnake(boolean humanSnake) {
        this.humanSnake = humanSnake;
    }

    public void setSnakeId(int id){
        this.snakeId = id;
    }
    public int getSnakeId(){
        return this.snakeId;
    }

    public boolean isObstacle() {
        return obstacle;
    }

    public void setObstacle(boolean obstacle) {
        this.obstacle = obstacle;
    }

    public boolean isGoal() {
        return goal;
    }

    public void setGoal(boolean goal) {
        this.goal = goal;
    }

    public boolean isAutomatic() {
        return automatic;
    }

    public void setAutomatic(boolean automatic) {
        this.automatic = automatic;
    }

    public int getValor() {
        return valor;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }
}
