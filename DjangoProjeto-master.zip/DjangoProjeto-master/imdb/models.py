from django.db import models
from django.contrib.auth.models import User
from django.db.models import Avg


class Movie(models.Model):
    id = models.CharField(max_length=200, primary_key=True)
    rank = models.IntegerField(default=0)
    title = models.CharField(max_length=200)
    year = models.IntegerField(blank=True, null=True)
    image = models.TextField(default='None')
    crew = models.CharField(max_length=200)
    imDbRating = models.DecimalField(max_digits=2, decimal_places=1, default=0)
    imDbRatingCount = models.IntegerField(default=0)

    def average_rating(self) -> float:
        return Rating.objects.filter(movie=self).aggregate(Avg("rating"))["rating__avg"] or 0

    def __str__(self):
        return f"{self.title}: {self.average_rating()}"


class MovieDetails(models.Model):
    id = models.CharField(max_length=200, primary_key=True)
    releaseDate = models.DateField()
    runTimeMins = models.IntegerField()
    plot = models.TextField(default="None")
    awards = models.CharField(max_length=200)
    directors = models.CharField(max_length=200)
    writers = models.CharField(max_length=200)
    stars = models.CharField(max_length=200)
    trailer = models.TextField(default=None, blank=True, null=True)
    genreList = models.TextField(default=None)
    similars = models.TextField(default=None)


class Rating(models.Model):
    movie = models.ForeignKey(Movie, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    rating = models.IntegerField(default=0)

    def __str__(self):
        return self.movie


class Users(models.Model):
    username = models.CharField(max_length=50, default="Empty")
    user = models.OneToOneField(User, on_delete=models.CASCADE)

    def __str__(self):
        return self.username
    class Meta:
        permissions = [
            ("is_premium", "Can comment and rate movies"),
            ("is_regular", "Can not comment or rate movies"),
        ]


class MovieComments(models.Model):
    comment = models.TextField(max_length=500)
    date = models.DateTimeField(auto_now_add=True)
    username = models.ForeignKey(User, on_delete=models.CASCADE)
    movie = models.ForeignKey(Movie, related_name="comments", on_delete=models.CASCADE)
    likes = models.ManyToManyField(User,through='CommentLike', related_name="likes")

    def total_likes(self):
        return self.likes.count()

    def __str__(self):
        return '%s - %s' % (self.movie.title, self.username.username)

class CommentLike(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    comment = models.ForeignKey(MovieComments, on_delete=models.CASCADE)