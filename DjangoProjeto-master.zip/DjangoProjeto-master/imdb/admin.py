from django.contrib import admin
from .models import MovieComments

# Register your models here.
admin.site.register(MovieComments)