from django.urls import include, path
from . import views


app_name = 'imdb'
urlpatterns = [
 path("", views.login_view, name="login"),
 #Login
 path("login/", views.login_view, name='login'),
 #Registar
 path('registar/', views.registar, name='registar'),
 #Logout
 path('logout/', views.Logout, name='logout'),
 path('homepage/', views.homePage, name='homePage'),
 path('<movie_id>/moviedetails/', views.movieDetails, name='movie_details'),
 path('<movie_id>/moviedetails/addComment/', views.addComment, name='addComment'),
 path('searchMovie/', views.searchMovie1, name='searchMovie1'),
 path('showAll/', views.showAll, name='showAll'),
 path('comingSoon/', views.comingSoon, name='comingSoon'),
 path('mostPopular/', views.mostPopular, name='mostPopular'),
 path('contact/', views.contact, name='contact'),
 path('<moviecomment_id>/delete/', views.deleteComment, name='deleteComment'),

 path('rating/<movie_id>/<int:rating>/', views.rating, name='rating'),
 path('<moviecomment_id>/like', views.like_comment, name='like_comment'),
path('<moviecomment_id>/unlike', views.unlike_comment, name='unlike_comment'),
]