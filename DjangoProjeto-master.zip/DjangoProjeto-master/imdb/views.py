import json
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required, permission_required
from django.contrib.auth.models import User, Permission
from django.contrib.contenttypes.models import ContentType
from django.shortcuts import render, redirect
from django.http import HttpResponseRedirect, HttpRequest, HttpResponse, JsonResponse
from django.urls import reverse
import requests
from .models import Movie, MovieDetails, MovieComments, Rating, CommentLike, Users

imdbKey = "k_nvfd9azd"
baseUrl = "https://imdb-api.com/en/API/"

####################################################################################################################

'''
Esta porção de código aqui dentro apenas serve para inicializar 
a base de dados pela primeira vez, ou seja,
se esta estiver vazia
'''


def getMovies():
    print(baseUrl + "Top250Movies/" + imdbKey)
    requestUrl = baseUrl + "Top250Movies/" + imdbKey
    response = requests.request("GET", requestUrl).json()['items']
    print(requests.request("GET", requestUrl).json())
    return response


def initMovie(movie):
    movie = Movie(id=movie['id'], rank=movie['rank'], title=movie['title'], year=movie['year'],
                  image=movie['image'], crew=movie['crew'],
                  imDbRating=movie['imDbRating'], imDbRatingCount=movie['imDbRatingCount'])
    movie.save()


def initMovies():
    movieList = getMovies()
    for movie in movieList:
        initMovie(movie)


'''DESCOMENTAR ESTA LINHA A PRIMEIRA VEZ QUE TIVER DE SER INICIALIZADA A BASE DE DADOS, OU SEJA, QUANDO A BD ESTIVER VAZIA
&
CORRER A APLICAÇÃO E COMENTAR NOVAMENTE APÓS A BASE DE DADOS ESTAR POPULADA'''
#initMovies()

####################################################################################################################


def login_view(request):
    if request.method == 'GET':
        return render(request, 'imdb/login.html', {'message': "Preencha os seguintes campos"})
    else:
        utilizador = request.POST['username']
        palavra_pass = request.POST['password']

        user = authenticate(username=utilizador, password=palavra_pass)

        if user is not None:
            login(request, user)
            context = {
                'utilizador': user
            }
            return HttpResponseRedirect(reverse('imdb:homePage'), context)
        else:

            return render(request, 'imdb/login.html', {'message': "Erro: Utilizador ou palavra-passe incorreto"})


def registar(request):
    if request.method == 'GET':
        return render(request, 'imdb/registar.html')
    else:
        username = request.POST['username']
        palavra_passe = request.POST['password']
        confirm_password = request.POST['confirm_password']
        email = request.POST['email']
        perm = request.POST['perm']

        if len(username) < 3 or len(username) > 20:
            message = 'Username has to be between 3-20 characters.'
            response_data = {'success': False, 'message': message}
            return JsonResponse(response_data)
        if User.objects.filter(username=username).exists():
            message = 'The username already exists. Choose another one...'
            response_data = {'success': False, 'message': message}
            return JsonResponse(response_data)
        if palavra_passe != confirm_password:
            message = 'Passwords do not match.'
            response_data = {'success': False, 'message': message}
            return JsonResponse(response_data)

        user: User = User.objects.create_user(
            username=username,
            password=palavra_passe,
            email=email
        )
        if perm in ['is_premium', 'is_regular']:
            conteudo = ContentType.objects.get_for_model(Users)
            permission = Permission.objects.get(content_type=conteudo, codename=perm)
            user.user_permissions.add(permission)

        user.save()
        users: Users = Users.objects.create(user=user)
        users.username = user.username

        response_data = {'success': True}
        return JsonResponse(response_data)


@login_required(login_url='/imdb/login')
def homePage(request):
    if request.user.is_authenticated:
        movies = Movie.objects.all()
        context = {
            'movies': movies[:20]
        }
        print(movies)
        return render(request, 'imdb/index1.html', context)
    return HttpResponseRedirect(reverse('imdb:login'))


def getMovieDetails(movie_id):
    movie = get_or_none(Movie, id=movie_id)
    requestUrl = baseUrl + "Title/" + imdbKey + "/" + movie_id
    requestTrailerUrl = baseUrl + "YouTubeTrailer/" + imdbKey + "/" + movie_id
    movie_trailer = requests.request("GET", requestTrailerUrl).json()
    movie_detail = requests.request("GET", requestUrl).json()
    print(movie_trailer)
    if movie is None:
        initMovieByMovieDetails(movie_detail)
    return initMovieDetails(movie_detail, movie_trailer)


def initMovieByMovieDetails(movie_details):
    movie = Movie(id=movie_details['id'], title=movie_details['title'],
                  year=movie_details['year'], image=movie_details['image'],
                  imDbRating=movie_details['imDbRating'],
                  imDbRatingCount=movie_details['imDbRatingVotes']
                  )
    movie.save()
    return movie


def initMovieDetails(movie_detail, movie_trailer):
    movie_detail_db = MovieDetails(id=movie_detail['id'], releaseDate=movie_detail['releaseDate'],
                                   runTimeMins=movie_detail['runtimeMins'], plot=movie_detail['plot'],
                                   awards=movie_detail['awards'], directors=json.dumps(movie_detail['directors']),
                                   writers=json.dumps(movie_detail['writers']),
                                   stars=json.dumps(movie_detail['stars']),
                                   trailer=movie_trailer['videoUrl'].replace("watch?v=", "embed/"),
                                   genreList=json.dumps(movie_detail['genres']),
                                   similars=json.dumps(movie_detail['similars']))

    movie_detail_db.save()
    return movie_detail_db


def get_or_none(classmodel, **kwargs):
    try:
        return classmodel.objects.get(**kwargs)
    except classmodel.DoesNotExist:
        return None

@login_required(login_url='/imdb/login')
def movieDetails(request, movie_id):

    movie_detail = get_or_none(MovieDetails, id=movie_id)
    if movie_detail is None:
        movie_detail = getMovieDetails(movie_id)

    movie = get_or_none(Movie, id=movie_id)
    movie_detail.similars = json.loads(movie_detail.similars)
    context = {
        'movie': movie,
        'movie_detail': movie_detail
    }
    movies = Movie.objects.all()
    for movie in movies:
        rating = Rating.objects.filter(movie=movie, user=request.user).first()
        movie.user_rating = rating.rating if rating else 0
    return render(request, 'imdb/movieDetail.html', context)

@login_required(login_url='/imdb/login')
@permission_required('imdb.is_premium')
def rating(request: HttpRequest, movie_id: str, rating: int) -> HttpResponse:
    movie = Movie.objects.get(id=movie_id)
    Rating.objects.filter(movie=movie, user=request.user).delete()
    rating = Rating(user=request.user, rating=rating, movie=movie)
    rating.save()
    return "Okay"

def getMoviesComingSoon():
    requestUrl = baseUrl + "ComingSoon/" + imdbKey
    return requests.request("GET", requestUrl).json()['items']

@login_required(login_url='/imdb/login')
def comingSoon(request):
    movies = getMoviesComingSoon()
    context = {
        'movies': movies[:20]
    }
    return render(request, 'imdb/comingSoon.html', context)

@login_required(login_url='/imdb/login')
def contact(request):
    return render(request, 'imdb/contactUs.html')

def getMostPopularMovies():
    requestUrl = baseUrl + "MostPopularMovies/" + imdbKey
    return requests.request("GET", requestUrl).json()['items']

@login_required(login_url='/imdb/login')
def mostPopular(request):
    movies = getMostPopularMovies()
    context = {
        'movies': movies[:20]
    }
    return render(request, 'imdb/mostPopular.html', context)

def getMoviesByTitle(title):
    print(baseUrl + "SearchMovie/" + imdbKey + "/" + title)
    requestUrl = baseUrl + "SearchMovie/" + imdbKey + "/" + title
    return requests.request("GET", requestUrl).json()['results']

@login_required(login_url='/imdb/login')
def searchMovie1(request):
    print("[searchMovie] entered movie")
    title = request.POST['titleName']
    movies = getMoviesByTitle(title)
    print("[searchMovie] movies ", movies)
    context = {
        'movies': movies,
        'searchTitle': title
    }
    return render(request, 'imdb/searchMovie.html', context)


def Logout(request):
    logout(request)
    return HttpResponseRedirect(reverse('imdb:login'))

@login_required(login_url='/imdb/login')
@permission_required('imdb.is_premium')
def addComment(request, movie_id):
    movie = get_or_none(Movie, pk=movie_id)
    comment = request.POST['comment']
    moviecomment = MovieComments(comment=comment, username=request.user, movie=movie)
    moviecomment.save()
    previous_page_url = request.META.get('HTTP_REFERER')
    return redirect(previous_page_url)

@login_required(login_url='/imdb/login')
def showAll(request):
    movies = Movie.objects.all()
    context = {
        'movies': movies
    }
    return render(request, 'imdb/showAll.html', context)

@login_required(login_url='/imdb/login')
def deleteComment(request, moviecomment_id):
    comment = get_or_none(MovieComments, id=moviecomment_id)
    if comment is not None and comment.username == request.user:
        comment.delete()
        return redirect(request.META.get('HTTP_REFERER', '/'))
    else:
        return HttpResponse("This comment it's not yours")


@login_required(login_url='/imdb/login')
def like_comment(request, moviecomment_id):
    comment = get_or_none(MovieComments, id=moviecomment_id)
    if comment is not None:
        comment.likes.add(request.user)
        return redirect(request.META.get('HTTP_REFERER', '/'))
    else:
        return HttpResponse("Comment doesn't exist!!")

@login_required(login_url='/imdb/login')
def unlike_comment(request, moviecomment_id):
    comment = get_or_none(MovieComments, id=moviecomment_id)
    if comment is not None:
        like = CommentLike.objects.get(comment=comment, user=request.user)
        like.delete()
        return redirect(request.META.get('HTTP_REFERER', '/'))
    else:
        return HttpResponse("Comment doesn't exist!!")