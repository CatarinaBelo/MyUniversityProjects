$(document).ready(function(){

	$(".movie_container").hover(function(){
		$(this).find(".play").show();

	},
	function()
	{
		$(this).find(".play").hide();
	});

	$(".blink").focus(function() {
            if(this.title==this.value) {
                this.value = '';
            }
        })
        .blur(function(){
            if(this.value=='') {
                this.value = this.title;
			}
		});
   const buttonRight = document.getElementById('slideRight');
   const buttonLeft = document.getElementById('slideLeft');

    buttonRight.onclick = function () {
      var container = document.getElementById('container_image_overflow');
                     scrollAmount = 0;
                var slideTimer = setInterval(function(){
                    container.scrollLeft += 10;
                    scrollAmount += 10;
                    if(scrollAmount >= 165){
                        window.clearInterval(slideTimer);
                    }
                }, 15);

    };
    buttonLeft.onclick = function () {
      var container = document.getElementById('container_image_overflow');
                           scrollAmount = 0;
                var slideTimer = setInterval(function(){
                    container.scrollLeft -= 10;
                    scrollAmount += 10;
                    if(scrollAmount >= 165){
                        window.clearInterval(slideTimer);
                    }
                }, 15);
   };



});

